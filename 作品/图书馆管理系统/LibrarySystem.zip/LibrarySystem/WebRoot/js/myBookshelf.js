$(function(){

	//鏍规嵁鎬у埆鏄剧ず鍥剧墖
	var sex = $(".sex").text().trim();
	if (sex === "濂�) {
		$("#sex-pic").attr("src","img/girl.png");
	}else if (sex === "鐢�) {
		$("#sex-pic").attr("src","img/boy.png");
	}else{
		$("#sex-pic").attr("src","img/sex-unknow.png");
	};


	//鍒囨崲閫夐」鍗★紝骞舵牴鎹搴旈�鍨嬪崱鏄剧ず鎸夐挳
	$(".card-btn").find("span").on("click",function(){
		var title = $(this).attr("title");
		var name = $(this).attr("id");
		var showName = name.split("-")[0];
		$(this).addClass("active").siblings("span").removeClass("active");
		$(this).parent().find("#"+showName+"-upload").show().siblings("a").hide();
		$("#container").find("#"+title).show().siblings("div").hide();
	});


	//閫夋嫨瀵瑰簲涔︽湰杩涜閫夋嫨鍒犻櫎鎿嶄綔
	var bookIdArr=[],bookId;
	$("span.delete-btn").on("click",function(){

		bookId = $(this).siblings("form").find(".book-id").attr("value");
		//鍒ゆ柇鏁扮粍閲屾槸鍚︽湁bookId,鏃犲垯杩斿洖-1
		if($.inArray(bookId ,bookIdArr) == - 1){ 
			$(this).css("background-image","url(img/delete1.jpg)");
			bookIdArr.push(bookId);
			// console.log(bookIdArr);
		}else{
			$(this).css("background-image","url(img/delete2.jpg)");
			bookIdArr = $.grep(bookIdArr,function(val){
				return val != bookId;
			});
			// console.log(bookIdArr);			
		}		
	});


	//鐐瑰嚮鍒犻櫎鍥炬爣锛岀‘璁ゆ槸鍚﹀垹闄�
	var flag  = false;
	$("#delete-book").on("click",function(){
		var flag = confirm("zz");
	})

});
