﻿/// <reference path="../jquery/jquery-1.4.1.min.js" />
$(function ()
{
    var _index = 0;

    //wzx
    //PiaoFu();

    //[HuangYu][2015/10/15]
    $(".kuang .author").eq(1).show();
    //选项卡切换
    $(".search>.list>a").hover(function ()
    {
        _index = $(this).index();

        $(".search>.list>a").removeClass("e");
        $(this).addClass("e");
        $(".btnSearch").val("请输入关键字进行检索");

        // if (_index == 0)
        // {//馆藏
        //     $(".kuang .author").hide();
        //     $(".kuang .author").eq(1).show();
        // }
        // else if (_index == 2) {
        //     $(".kuang .author").hide();
        // }
        // else if (_index == 4) {
        //     $(".kuang .author").hide();
        // }
        // else if (_index == 6) {
        //     $(".kuang .author").hide();
        //     $(".kuang .author").eq(2).show();
        // }
        if (_index == 0)
        {//馆藏
            $(".kuang .author").hide();
            $(".kuang .author").eq(1).show();
        }
        else if (_index == 2) {
            $(".kuang .author").hide();
        }
        else if (_index == 4) {
            $(".kuang .author").hide();
            $(".kuang .author").eq(2).show();
        }

    })

    //点击搜索
    $(".kuang>.right").click(function ()
    {
        if ($(".btnSearch").val() == "" || $(".btnSearch").val() == "请输入关键字进行检索")
        {
            tips.alert("请输入检索关键字进行检索", 1, 1500);
        }
        // else if (_index == 0)
        // { //馆藏书目搜索
        //     GuanCangSearch();
        // }
        // //[HuangYu][2015/10/15]
        // else if (_index == 2) { //超星发现
        //     ZhiZhenSearch();
        // }
        // else if (_index == 4) { //百度学术
        //     BaiduXS();
        // }
        // //[WZX][2016/11/04]
        // else if (_index == 6) { //期刊搜索
        //     Periodical();
        // }
        else if (_index == 0)
        { //馆藏书目搜索
            GuanCangSearch();
        }
        else if (_index == 2) { //百度学术
            BaiduXS();
        }
        //[WZX][2016/11/04]
        else if (_index == 4) { //期刊搜索
            Periodical();
        }

    })
    //回车
    $("#Text1").keydown(function (event)
    {
        if (event.keyCode == 13)
        {
            $(".kuang>.right").click();
            return false;
        }
    });



    $(".btnSearch").live("click", function ()
    {
        $(this).val("");
    })
    //下拉
    $(".kuang .author>span").live("click", function ()
    {
        $(this).parent().children(".author_down").slideToggle();
    })
    //失焦
    $(".btnSearch").live("blur", function ()
    {
        if ($(".btnSearch").val() == "")
        {
            $(this).val("请输入关键字进行检索");
        }
    })
    $(".kuang .author ").mouseleave(function ()
    {
        $(this).children(".author_down").slideUp();
    })

    //百链
    $("#BaiLian>.author_down>a").live("click", function ()
    {
        $("#ww").attr("valtwo", $(this).attr("valtwo"));
        $("#ww").attr("val", $(this).attr("val"));
        $("#ww").text($(this).text());
        $("#BaiLian>.author_down").hide();
    })
    //馆藏
    $("#GuanCang>.author_down>a").live("click", function ()
    {
        $("#gc").attr("valtwo", $(this).attr("valtwo"));
        $("#gc").attr("val", $(this).attr("val"));
        $("#gc").text($(this).text());
        $("#GuanCang>.author_down").hide();
    })
    //期刊
    $("#Periodical>.author_down>a").live("click", function () {
        $("#pd").attr("val", $(this).attr("val"));
        $("#pd").text($(this).text());
        $("#Periodical>.author_down").hide();
    })
    /**
    //超星发现检索
    function ZhiZhenSearch()
    {
        window.open("http://www.zhizhen.com/s?sw=" + $(".btnSearch").val());
    }
    //中文检索
    function ChineseSearch()
    {
        window.open("http://www.zhizhen.com/s?sw=" + $(".btnSearch").val() + "&size=15&isort=0&x=0_185");
    }
    //外文检索
    function EnglishSearch()
    {
        window.open("http://gzhu.summon.serialssolutions.com/#!/search?ho=t&l=za-CN&q=" + $(".btnSearch").val());
    }
    //百链
    function BaiLianSearch()
    {
        var _type = $(".kuang .author>span").attr("val");
        var _searchType = $(".kuang .author>span").attr("valtwo");
        var sw = $(".btnSearch").val();
        var URL = "http://" + _type + ".blyun.com/" + _searchType;
        var parameter = "?Field=all&channel=" + _searchType;
        var searchText = "";
        $.ajax({
            type: "POST",
            url: "CommonFunction.axd",
            data: {
                type: "GetUTF8",
                value: sw
            },
            dataType: "text",
            async: false,
            success: function (data)
            {
                searchText = data;
            }
        });
        var _last = "&ecode=utf-8&edtype=&searchtype=&view=0";
        parameter += "&sw=" + searchText + _last;

        window.open(URL + parameter);
    }
    //馆藏书目
    function GuanCangSearch()
    {
        var URL = "http://lib.gzhu.edu.cn:8080/bookle/?query=" + $("#gc").attr("val");
        var sw = $(".btnSearch").val();
        window.open(URL + sw);
    }

    //期刊书目
    function Periodical() {
        var pdval = $("#pd").attr("val");
        var URL = "";
        var Keyword = $(".btnSearch").val();
        if (pdval == "Periodical") {
            URL = "http://www.spischolar.com/journal/search/list?value=" + Keyword;
        } else {
            URL = "http://www.spischolar.com:80/scholar/list?val=" + Keyword;
        }
        window.open(URL);
    }

    //百度学术
    function BaiduXS()
    {
        window.open("http://xueshu.baidu.com/s?wd="+ $(".btnSearch").val()
            + "&tn=SE_baiduxueshulib_9r82kicg&sc_as_para=sc_lib:gzhu&sc_from=gzhu");
    }

    BannerDown();
})

//导航下拉
function BannerDown()
{
    $(".header>.top>.nav>ul>li:gt(0)").live("mouseover", function ()
    {
        var index = $(this).index();
        var width = $(this).width() - 5;
        var left = 0;
        for (var i = 0; i < index; i++)
        {
            left += $(".header>.top>.nav>ul>li").eq(i).width();
        }
        $(".header>.top>.nav>.downlist>div").hide();
        $(".header>.top>.nav>.downlist>div").eq(index - 1).css({ "display": "block", "margin-left": left - 6 })
        //$(".nav>.downlist a").css("width",width+8);
    })
    $(".top>.nav>ul>li:eq(0)").live("mouseover", function ()
    {
        $(".top>.nav>.downlist>div").hide();
    })

}
/*
*//*
function PiaoFu()
{
    var pfUrl = "http://lib.gzhu.edu.cn/w/home/article/bf7a5157-3d59-47bf-a1e3-e9edcaab97db?channel=1ef4d1d5-efd6-457f-bbb3-b4ae03e0524f";
    var img = "/w/static/WebUI/images/_float.gif";
    var width = 190;
    var height = 98;
    var urlXml = "/w/static/";

    var Pfhtml = "<div id=\"floatDiv\" style=\"left: 580.15px; top: 312.89px; position: absolute; z-index:9999999999;\">" +
       "<a id=\"floatLink\" href=\"" + pfUrl + "\" target=\"_blank\">" +
       "<img id=\"floatImg\" src=\"" + img + "\" style=\"width:" + width + "; height:" + height + ";\"></a>" +
       "<div id=\"floatCloseDiv\" style=\"top: 0px; right: -25px; overflow: hidden; position: absolute; z-index: 99; cursor: pointer;\" onclick=\"$('#floatDiv').css('display','none');\">" +
       "<img src=\"" + urlXml + "CommonFunction_2/Pictures/shut.jpg\"></div>" +
       "</div>";
    $("body").append(Pfhtml);

    var ad = new AdMove("floatDiv");

    ad.Run();
    
}*/





