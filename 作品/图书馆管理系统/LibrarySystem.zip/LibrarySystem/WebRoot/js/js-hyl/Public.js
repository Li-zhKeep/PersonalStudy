﻿/// <reference path="../jquery/jquery-1.4.1.min.js" />
/// <reference path="http://localhost:22089/w/CommonFunction_2/Public/UrlGet.js" />

/**************************************************自定义设置********************************************************************/

$(function ()
{
    //wzx
    // //右上角三个图标
    // $(".quick_icon").html("<a href=\"http://118.244.213.93:8090/w/ArticleShow.html?Id=3e3d8f82-2ff7-40c5-92d4-1e9f7cf0c633\"><img src=\"/w/WebUI/images/ico1.png\" /><br />校外访问</a>" +
    //                   "<a target=\"_blank\" href=\"http://lib.gzhu.edu.cn/opac/LoginSystem.aspx\"><img src=\"/w/WebUI/images/ico2.png\" /><br />借阅查询</a>" +
    //                   "<a target=\"_blank\" href=\"http://lib.gzhu.edu.cn:8080/BookRecommend/\"><img src=\"/w/WebUI/images/ico3.png\" /><br />图书荐购</a>");
    // //底部
    // var str = "";
    // if (Str == "Index.html")
    // {
    //     str = "<p>";
    //     str += "<span>您是本站第</span><span id='VisitTime'></span><span>位访客</span>";
    //     str += "<span>今日进馆人次:</span><a style='color:#fff;' href='http://lib.gzhu.edu.cn:8080/bookle/goLibTotal/index' id='DaliyVisit'></a>";
    //     str += "<span style='position:relative' class='weixin'> <img src='WebUI/images/iconfont-weixin.png' height='25' width='25'/><img class='hiddenpic' style='position:absolute;top:-117px;right:0;display:none' height='100' width='100' src='WebUI/images/QRWeiXin.jpg' /></span>";
    //     str += "<a href='http://weibo.com/gzhulib' target='_blank' class='weibo' style='position:relative'><img src='WebUI/images/iconfont-weibo.png' height='25' width='25'/><img class='hiddenpic' style='position:absolute;top:-120px;left:0;display:none' height='100' width='100' src='WebUI/images/QRWeibo.png' /> </a></p>";
    //
    // }
    // else
    // {
    //     str = "<p><span>您是本站第</span><span id='VisitTime'></span><span>位访客</span><span>今日进馆人次:</span><a style='color:#262626;' href='http://lib.gzhu.edu.cn:8080/bookle/goLibTotal/index' id='DaliyVisit'></a></p>  ";
    // }
    // str += "<p><span>Copy Right©2014</span><span>广州大学图书馆</span><span>地址：广州番禺区大学城外环西路230号</span><span>邮编:510006</span><span>技术支持：上海上业信息科技有限公司</span></p>  ";
    // $(".foot,.main1").html(str);
    //
    // //Logo
    // $(".logo a").attr("href", "Index.html");


    $(".weixin").live("mouseenter", function ()
    {
        $(this).children(".hiddenpic").show();
    })
    $(".weixin").live("mouseleave", function ()
    {
        $(this).children(".hiddenpic").hide();
    })

    $(".weibo").live("mouseenter", function ()
    {
        $(this).children(".hiddenpic").show();
    })
    $(".weibo").live("mouseleave", function ()
    {
        $(this).children(".hiddenpic").hide();
    })

})
/*******************************************************************************************************************************/


$(function ()
{
    //检索框聚焦失焦


    //wzx
    // $(".search>.kuang>input").focus(function ()
    // {
    //     if ($(this).val() == "站内检索")
    //     {
    //         $(this).val("");
    //         $(this).css("color", "#121212");
    //     }
    // }).blur(function ()
    // {
    //     if ($(this).val() == "")
    //     {
    //         $(this).val("站内检索");
    //         $(this).css("color", "#d9d9d9");
    //     }
    // })
    // //动态添加检索下拉框
    // var name = window.location.pathname.split("/")[2];
    // if (name != "Index.html" && name != "")
    // {
    //     $(".search>.kuang").prepend("<div class=\"search_down fleft\"><p>新闻</p>"
    //                         + "<div class=\"sea_down\" style=\" display:none;\">"
    //                         + " <a class=\"e\" href=\"javascript://\" reftype=\"Search\">新闻</a>"
    //                         + "<a href=\"javascript://\" reftype=\"ResourcesList\">资源</a>"
    //                         + "<a href=\"javascript://\" reftype=\"CommonTools\">下载</a>"
    //                         + "</div></div>");
    // }
    //检索下拉
    // $(".search_down>p").live("mouseenter", function ()
    // {
    //     $(this).siblings("div").slideDown();
    // })
    // $(".search_down").mouseleave(function ()
    // {
    //     $(".search_down>div").slideUp();
    // })
    // //跳转页面类型
    // var searchType = "Search";
    // $(".sea_down>a").live("click", function ()
    // {
    //     $(".search_down>p").text($(this).text());
    //     $(".search_down>div").slideUp();
    //     $(".sea_down a").removeClass("e");
    //     $(this).addClass("e");
    //     searchType = $(this).attr("reftype");
    // })
    // //检索
    // $(".search>.but").click(function ()
    // {
    //     if ($(".search>.kuang>input").val() != "" && $(".search>.kuang>input").val() != "站内检索")
    //     {
    //         var value = $(".kuang input").val();
    //         //判断跳转哪个页面
    //         if (searchType == "Search")
    //         {
    //             location.href = "Search.html?SearchContent=" + value + "&ContentType=ArticleList.html";
    //         }
    //         else if (searchType == "ResourcesList")
    //         {
    //             location.href = "ResourcesList.html?SearchContent=" + value + "&ContentType=ResourcesList.html";
    //         }
    //         else if (searchType == "CommonTools")
    //         {
    //             location.href = "CommonTools.html?SearchContent=" + value + "&ContentType=CommonTools.html";
    //         }
    //     }
    //     else
    //     {
    //         tips.alert("请输入检索词", 1, 1500);
    //     }
    // })
    // //回车事件
    // $(".search>.kuang>input").keydown(function (e)
    // {
    //     if (e.keyCode == 13)
    //     {
    //         $(".search>.but").click();
    //     }
    // })
    // //保留检索条件与字段
    // SetSearchCondition();

    //wzx
    //WriteVisit();       //历史访问量
    NavDown();          //导航下拉
    //wzx
    //Ajax("#DaliyVisit");   //今日入馆人数
})

//保留检索条件与字段
function SetSearchCondition()
{
    //检索字段
    var searchText = $.query.get("SearchContent");
    $(".search_down").siblings().val(searchText);
    if (searchText != "")
    {
        var str = window.location.pathname.split("/")[2];
        switch (str)
        {
            case "Search.html": $(".search_down>p").text("新闻"); break;
            case "ResourcesList.html": $(".search_down>p").text("资源"); break;
            case "CommonTools.html": $(".search_down>p").text("下载"); break;
        }
    }
    else
    {
        $(".search>.kuang>input").val("站内检索");
        $(".search>.kuang>input").css("color", "#d9d9d9");
    }
}


//左侧二级导航首行名称
//wzx
// setTimeout(function ()
// {
//     var FirstTitle = $(".break>.fright>a").eq(1).text();
//     var LastTitle = $(".break>.fright>a:last").text();
//     $(".break h3").html(LastTitle);
//     $(".left_nav .tit").html(FirstTitle);
// }, 190)

//历史访问量
function WriteVisit()
{
    $.ajax({
        type: "POST",
        data: {
            type: "WriteVisit",
            path: "ShangYeVisit.txt"
        },
        dataType: "text",
        url: "CommonFunction.axd",
        async: false, //ajax同步提交
        success: function (data)
        {
            $("#VisitTime").text(data);
        }
    });
}

//今日访问量
function DaliyVisit()
{
    $.ajax({
        type: "POST",
        data: {
            type: "DailyVisit",
            path: "ShangYeGz_Library"
        },
        dataType: "text",
        url: "CommonFunction.axd",
        async: false, //ajax同步提交
        success: function (data)
        {
            $("#DaliyVisit").text(data);
        }
    });
}

//只适应
function setsj()
{
    var height = $(window).height();
    var width = $(window).width();
    $("body,.right_nav").height(height + "px");

    $(".box_bg>img").css("width", width + "px");
    $(".box_bg>img").css("height", height + "px");
}

//二级页面导航下拉
function NavDown()
{
    $(".nav>.banner>ul>li:gt(0)").live("mouseenter", function ()
    {
        var index = $(this).index();
        var width = $(this).width() - 16;

        if ($(".nav>.downlist>div").eq(index - 1).children("a").length == 0)
        {
            $(".nav>.downlist>div").hide();
        }
        else
        {
            var left = 14;
            for (var i = 0; i < index; i++)
            {
                left += $(".nav>.banner>ul>li").eq(i).width();
            }

            $(".nav>.downlist>div").hide();
            $(".nav>.downlist>div").eq(index - 1).css({ "display": "block", "margin-left": left });
            // $(".downlist a").css("width", width);
            if ($(".nav>.downlist>div").eq(index - 1).children("a").width() < width)
            {
                $(".nav>.downlist>div").eq(index - 1).css({ "width": width + 16 });
            }
            //alert(ww);
        }
    })
    $(".nav>.downlist>div").live("mouseleave", function ()
    {
        $(this).hide();
    })
    $(".header>.nav").mouseleave(function ()
    {
        $(".nav>.downlist>div").hide();
    })
    $(".nav>.banner>ul>li:eq(0)").live("mouseover", function ()
    {
        $(".nav>.downlist>div").hide();
    })

}

//远程获取页面内容
function Ajax(container)
{
    $.ajax({
        type: "POST",
        url: "/w/CommonFunction_2/Ajax/GzDailyVisit.ashx",
        dataType: "text",
        beforeSend: function (data)
        {

        },
        success: function (data)
        {

            var totalStr = $(data).find("#total").text();
            var totalNo = totalStr.split(":")[1];
            $(container).html(totalNo);
        },
        error: function (msg)
        {
            //$.tips.Alert.Warning({ Title: "系统提示", Content: "系统出现问题", IsCancel: "no", OKClass: "bot_confirm" });
        }

    });
}

//设为首页 兼容360和IE6
function SetHome(obj, vrl) {
    try {
        obj.style.behavior = 'url(#default#homepage)'; obj.setHomePage(vrl);
    }
    catch (e) {
        if (window.netscape) {
            try {
                netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
            }
            catch (e) {
                tips.alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将 [signed.applets.codebase_principal_support]的值设置为'true',双击即可。", 1, 4500);
            }
            var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
            prefs.setCharPref('browser.startup.homepage', vrl);
        } else {
            tips.alert("您的浏览器不支持，请按照下面步骤操作：1.打开浏览器设置。2.点击设置网页。3.输入：" + vrl + "点击确定。", 1, 4500);
        }
    }
}
//加入收藏 兼容360和IE6
function shoucang(sTitle, sURL) {
    try {
        window.external.addFavorite(sURL, sTitle);
    }
    catch (e) {
        try {
            window.sidebar.addPanel(sTitle, sURL, "");
        }
        catch (e) {
            tips.alert("加入收藏失败，请使用Ctrl+D进行添加", 1, 4500);
        }
    }
}

