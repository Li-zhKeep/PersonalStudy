(function($) {        
    $.alerts = {         
        alert: function(title, message, callback) {  
            if( title == null ) title = 'Alert';  
            $.alerts._show(title, message, null, 'alert', function(result) {  
                if( callback ) callback(result);  
            });  
        },  
           
        confirm: function(title, message, callback) {  
            if( title == null ) title = 'Confirm';  
            $.alerts._show(title, message, null, 'confirm', function(result) {  
                if( callback ) callback(result);  
            });  
        },  
               
          
        _show: function(title, msg, value, type, callback) {  
            
                    var _html = "";  
   
                    _html += '<div id="mb_box"></div><div id="mb_con"><span id="mb_tit">' + title + '</span>';  
                    _html += '<div id="mb_msg">' + msg + '</div><div id="mb_btnbox">';  
                      if (type == "alert") {  
                      _html += '<input id="mb_btn_ok" type="button" value="确   定" />';  
                    }  
                    if (type == "confirm") {  
                      _html += '<input id="mb_btn_no" type="button" value="鍙栨秷" />';  
                      _html += '<input id="mb_btn_ok" type="button" value="纭畾" />';  
                    }  
                    _html += '</div></div>';  
                   
                    //蹇呴』鍏堝皢_html娣诲姞鍒癰ody锛屽啀璁剧疆Css鏍峰紡  
                    $("body").append(_html); GenerateCss();  
           
            switch( type ) {  
                case 'alert':  
          
                    $("#mb_btn_ok").click( function() {  
                        $.alerts._hide();  
                        callback(true);  
                    });  
                    $("#mb_btn_ok").focus().keypress( function(e) {  
                        if( e.keyCode == 13 || e.keyCode == 27 ) $("#mb_btn_ok").trigger('click');  
                    });  
                break;  
                case 'confirm':  
                     
                    $("#mb_btn_ok").click( function() {  
                        $.alerts._hide();  
                        if( callback ) callback(true);  
                    });  
                    $("#mb_btn_no").click( function() {  
                        $.alerts._hide();  
                        if( callback ) callback(false);  
                    });  
                    $("#mb_btn_no").focus();  
                    $("#mb_btn_ok, #mb_btn_no").keypress( function(e) {  
                        if( e.keyCode == 13 ) $("#mb_btn_ok").trigger('click');  
                        if( e.keyCode == 27 ) $("#mb_btn_no").trigger('click');  
                    });  
                break;
            }  
        },  
        _hide: function() {  
             $("#mb_box,#mb_con").remove();  
        }  
    }  
    // Shortuct functions  
    myAlert = function(title, message, callback) {  
        $.alerts.alert(title, message, callback);  
    }  
    
    MyAlert = function(message, callback) { 
    	title = "<img src=\"${pageContext.request.contextPath}/header_lib/img/logo_260px_active.png\" style=\"height:20px;\">";
        $.alerts.alert(title, message, callback);  
    } 
    
    myConfirm = function(title, message, callback) {  
        $.alerts.confirm(title, message, callback);  
    };  
           
   
      
      //鐢熸垚Css  
  var GenerateCss = function () {  
   
    $("#mb_box").css({ width: '100%', height: '100%', zIndex: '99999', position: 'fixed',  
      filter: 'Alpha(opacity=60)', backgroundColor: 'black', top: '0', left: '0', opacity: '0.6'
    });  
   
    $("#mb_con").css({ zIndex: '999999', width: '350px',height:'180px', position: 'fixed',  
      backgroundColor: 'White',  borderRadius: '4px'
    });  
   
    $("#mb_tit").css({ display: 'block', fontSize: '14px', color: '#444', padding: '10px 15px',  
      backgroundColor: '#fff', borderRadius: '15px 15px 0 0',  
      fontWeight: 'bold'  
    });  
   
    $("#mb_msg").css({ padding: '10px', lineHeight: '40px', textAlign:'center', 
      fontSize: '20px' ,color:'#4c4c4c'
    });  
   
    $("#mb_ico").css({ display: 'block', position: 'absolute', right: '10px', top: '9px',  
      border: '1px solid Gray', width: '18px', height: '18px', textAlign: 'center',  
      lineHeight: '16px', cursor: 'pointer', borderRadius: '12px', fontFamily: '寰蒋闆呴粦'  
    });  
   
    $("#mb_btnbox").css({ margin: '15px 0px 10px 0', textAlign: 'center' });  
    $("#mb_btn_ok,#mb_btn_no").css({fontSize: '18px' , width: '120px', height: '40px', color: 'white', border: 'none', borderRadius:'4px'});  
    $("#mb_btn_ok").css({ backgroundColor: '#23abf0' });  
    $("#mb_btn_no").css({ backgroundColor: 'gray', marginRight: '40px' });  
   
   
    //鍙充笂瑙掑叧闂寜閽甴over鏍峰紡  
    $("#mb_ico").hover(function () {  
      $(this).css({ backgroundColor: 'Red', color: 'White' });  
    }, function () {  
      $(this).css({ backgroundColor: '#DDD', color: 'black' });  
    });  
   
    var _widht = document.documentElement.clientWidth; //灞忓箷瀹� 
    var _height = document.documentElement.clientHeight; //灞忓箷楂� 
   
    var boxWidth = $("#mb_con").width();  
    var boxHeight = $("#mb_con").height();  
   
    $("#mb_con").css({ top: (_height - boxHeight) / 2 + "px", left: (_widht - boxWidth) / 2 + "px" });  
  }  
   
  
})(jQuery);