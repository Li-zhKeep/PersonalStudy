(function($) {        
    $.addUserAlerts = {         
        alert: function(title, message, callback) {  
            if( title == null ) title = 'Alert';  
            $.addUserAlerts._show_AddUser(title, message, null, 'alert', function(result) {  
                if( callback ) callback(result);  
            });  
        },  
           
        confirm: function(title, message, callback) {  
            if( title == null ) title = 'Confirm';  
            $.addUserAlerts._show_AddUser(title, message, null, 'confirm', function(result) {  
                if( callback ) callback(result);  
            });  
        },  
               
          
        _show_AddUser: function(title, msg, value, type, callback) {  
            
                    var _html = "";  
   
                    _html += '<div id="mb_box"></div><div id="mb_con"><span id="mb_tit">' + title + '</span>';  
                    _html += '<div id="mb_msg">' + msg + '</div><div id="mb_btnbox">';  
                      if (type == "alert") {  
                      _html += '<input id="mb_btn_ok" type="button" value="纭�  瀹� />';  
                    }  
                    if (type == "confirm") {  
                      _html += '<input id="mb_btn_no" type="button" value="閸欐牗绉� />';  
                      _html += '<input id="mb_btn_ok" type="button" value="绾喖鐣� />';  
                    }  
                    _html += '</div></div>';  
                   
                    //韫囧懘銆忛崗鍫濈殺_html濞ｈ濮為崚鐧皁dy閿涘苯鍟�拋鍓х枂Css閺嶅嘲绱� 
                    $("body").append(_html); GenerateCss();  
           
            switch( type ) {  
                case 'alert':  
          
                    $("#mb_btn_ok").click( function() {  
                        $.addUserAlerts._hide();  
                        callback(true);  
                    });  
                    $("#mb_btn_ok").focus().keypress( function(e) {  
                        if( e.keyCode == 13 || e.keyCode == 27 ) $("#mb_btn_ok").trigger('click');  
                    });  
                break;  
                case 'confirm':  
                     
                    $("#mb_btn_ok").click( function() {  
                        $.addUserAlerts._hide();  
                        if( callback ) callback(true);  
                    });  
                    $("#mb_btn_no").click( function() {  
                        $.addUserAlerts._hide();  
                        if( callback ) callback(false);  
                    });  
                    $("#mb_btn_no").focus();  
                    $("#mb_btn_ok, #mb_btn_no").keypress( function(e) {  
                        if( e.keyCode == 13 ) $("#mb_btn_ok").trigger('click');  
                        if( e.keyCode == 27 ) $("#mb_btn_no").trigger('click');  
                    });  
                break;
            }  
        },  
        _hide: function() {  
             $("#mb_box,#mb_con").remove();  
        }  
    }  
    // Shortuct functions  
    UserAddAlert = function(title, message, callback) {  
        $.addUserAlerts.alert(title, message, callback);  
    }  
    
    UserAddAlert = function(message, callback) { 
    	title = "<img src=\"header_lib/img/logo_260px_active.png\" style=\"height:20px;\">";
        $.addUserAlerts.alert(title, message, callback);  
    } 
    
    myConfirm = function(title, message, callback) {  
        $.addUserAlerts.confirm(title, message, callback);  
    };  
           
   
      
      //閻㈢喐鍨欳ss  
  var GenerateCss = function () {  
   
    $("#mb_box").css({ width: '100%', height: '100%', zIndex: '99999', position: 'fixed',  
      filter: 'Alpha(opacity=60)', backgroundColor: 'black', top: '0', left: '0', opacity: '0.6'
    });  
   
    $("#mb_con").css({ zIndex: '999999', width: '850px',height:'360px', position: 'fixed',  
      backgroundColor: 'White',  borderRadius: '4px'
    });  
   
    $("#mb_tit").css({ display: 'block', fontSize: '14px', color: '#444', padding: '10px 15px',  
      backgroundColor: '#fff', borderRadius: '15px 15px 0 0',  
      fontWeight: 'bold'  
    });  
   
    $("#mb_msg").css({ padding: '-30px', lineHeight: '40px', textAlign:'center', 
      fontSize: '20px' ,color:'#4c4c4c' , marginTop: '-20px'
    });  
   
    $("#mb_ico").css({ display: 'block', position: 'absolute', right: '10px', top: '9px',  
      border: '1px solid Gray', width: '18px', height: '18px', textAlign: 'center',  
      lineHeight: '16px', cursor: 'pointer', borderRadius: '12px', fontFamily: '瀵邦喛钂嬮梿鍛寸拨'  
    });  
   
    $("#mb_btnbox").css({ margin: '15px 0px 10px 0', textAlign: 'center' });  
    $("#mb_btn_ok,#mb_btn_no").css({fontSize: '18px' , width: '120px', height: '40px', color: 'white', border: 'none', borderRadius:'4px'});  
    $("#mb_btn_ok").css({ backgroundColor: '#23abf0' });  
    $("#mb_btn_no").css({ backgroundColor: 'gray', marginRight: '40px' });  
   
   
    //閸欏厖绗傜憴鎺戝彠闂傤厽瀵滈柦鐢磑ver閺嶅嘲绱� 
    $("#mb_ico").hover(function () {  
      $(this).css({ backgroundColor: 'Red', color: 'White' });  
    }, function () {  
      $(this).css({ backgroundColor: '#DDD', color: 'black' });  
    });  
   
    var _widht = document.documentElement.clientWidth; //鐏炲繐绠风�锟�
    var _height = document.documentElement.clientHeight; //鐏炲繐绠锋锟�
   
    var boxWidth = $("#mb_con").width();  
    var boxHeight = $("#mb_con").height();  
   
    $("#mb_con").css({ top: ((_height - boxHeight) / 2 - 150 ) + "px", left: (_widht - boxWidth) / 2 + "px" });  
  }  
   
  
})(jQuery);