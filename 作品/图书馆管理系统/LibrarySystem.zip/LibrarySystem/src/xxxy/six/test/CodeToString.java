package xxxy.six.test;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.junit.Test;
/**
 * 
 * */
public class CodeToString {

	private static final Integer ONE = 1;

	@Test
	public void StringFormatToCode() {
		try {
			FileInputStream inputStream = new FileInputStream(new File(
					"C:/Users/ws/Desktop/wz.txt"));
			InputStreamReader inputStreamReader = new InputStreamReader(
					inputStream, "UTF-8");
			BufferedReader br = new BufferedReader(inputStreamReader);
			String lineTxt = null;
			while ((lineTxt = br.readLine()) != null) {
				String str = lineTxt.substring(1, lineTxt.length() - 2);
				int spaceCnt = 0;
				for (int i = str.length() - 1; i >= 0; i--) {
					if (str.charAt(i) == '	') {
						spaceCnt++;
					} else {
						break;
					}
				}
				str = str.substring(0, str.length() - spaceCnt);
				for (int i = 1; i < str.length(); i++) {
					if (str.charAt(i) == '\"' && str.charAt(i - 1) == '\\') {
						str = str.substring(0, i - 1)
								+ str.substring(i, str.length());
					}
				}
				System.out.println(str);
			}
			br.close();
		} catch (Exception e) {
			System.err.println("read errors :" + e);
		}
	}
	
	@Test
	public void CodeFormatToString() {
		try {
			FileInputStream inputStream = new FileInputStream(new File(
					"C:/Users/ws/Desktop/zz.txt"));
			InputStreamReader inputStreamReader = new InputStreamReader(
					inputStream, "UTF-8");
			BufferedReader br = new BufferedReader(inputStreamReader);
			String lineTxt = null;
			List<String> strings = new ArrayList<String>();
			int maxn = 0;
			while ((lineTxt = br.readLine()) != null) {
				String str = CodeToString(lineTxt);
				if(str.length() >= maxn ){
					maxn = str.length();
				}
				strings.add(str);
			}
			for (int i = 0; i < strings.size(); i++) {
				int addSpaceCnt = (maxn+1) - strings.get(i).length() ;
				String this_str = strings.get(i);
				for (int j = 0; j < addSpaceCnt; j++) {
					this_str += " ";
				}
				if(i == strings.size()-1){
					this_str += "\";";									
				} else {
					this_str += "\"+";					
				}					
				System.out.println(this_str);									
			}
			
			
			br.close();
		} catch (Exception e) {
			System.err.println("read errors :" + e);
		}
	}
	
	
	public String CodeToString(String str){
		//System.out.println("str");
		//String str = "<div id=\"addNewReaderPage\" class=\"row tpl-page-container\" style=\"margin:0px 5px 0px 5px\">";
		String str2 = "";
		String[] strings = str.split("\"");
		for (int i = 0; i < strings.length - 1; i++) {
		//	System.out.println(strings[i]);
			str2 += strings[i];
			str2 +=	"\\\"";
		}
		str2 += strings[strings.length-1];
		String str3 = "\"" + str2;
		//System.out.println(str3);
		return str3;
	}
	
}
