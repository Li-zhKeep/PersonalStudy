package xxxy.six.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;
import xxxy.six.entity.Boob;
import xxxy.six.entity.Reader;
import xxxy.six.filter.EncodingFilter;
import xxxy.six.service.BookRackService;
import xxxy.six.service.BookRackServiceimp;
import xxxy.six.service.ReaderService;
import xxxy.six.service.ReaderServiceImp;
import xxxy.six.service.SystemService;
import xxxy.six.service.SystemServiceimp;

import com.opensymphony.xwork2.ActionSupport;

public class QueryAction extends ActionSupport {
	ReaderService readerservice = new ReaderServiceImp();
	SystemService systemservice = new SystemServiceimp();
	BookRackService borrowservice = new BookRackServiceimp();

	private String result;
	private String borrow_result;
	private String get_num_reader_result;
	private String get_num_borrow_result;
	
	public String getBorrow_result() {
		return borrow_result;
	}

	public void setBorrow_result(String borrow_result) {
		this.borrow_result = borrow_result;
	}

	public String getGet_num_borrow_result() {
		return get_num_borrow_result;
	}

	public void setGet_num_borrow_result(String get_num_borrow_result) {
		this.get_num_borrow_result = get_num_borrow_result;
	}

	public String getGet_num_reader_result() {
		return get_num_reader_result;
	}

	public void setGet_num_reader_result(String get_num_reader_result) {
		this.get_num_reader_result = get_num_reader_result;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	// ��ѯ���ж��߸�����Ϣ
	public String QueryAllReaderInfo() throws Exception {
		//System.out.println("AllReaderInfo()");
		List<Reader> readerList = readerservice.queryAllReaderInfo();
		//System.out.println("------------------------------------------------------------------");
		for (Reader reader : readerList) {
			System.out.println(reader.toString());
		}
		Map<String, Object> map = new HashMap<String, Object>();
		if (!readerList.isEmpty()) {
			System.out.println("!readerList.isEmpty()");
			map.put("query_status", "success");
			map.put("readerList", readerList);
		} else {
			map.put("query_status", "error");
		}
		JSONObject json = JSONObject.fromObject(map);
		result = json.toString();
		return "qari_success";
	}

	public String QueryNumForAllReaderInfo() throws Exception {
		System.out.println("QueryNumForAllReaderInfo()");
		List<Reader> readerList = readerservice.queryAllReaderInfo();
		Map<String, Object> map = new HashMap<String, Object>();
		if (!readerList.isEmpty()) {
			int size = readerList.size();
			map.put("query_num", size);
		} else {
			map.put("query_num", 0);
		}
		JSONObject json = JSONObject.fromObject(map);
		get_num_reader_result = json.toString();
		return "get_num_for_reader_info_success";
	}
	
	// ��ѯ���н�����Ϣ
	public String QueryAllBorrowInfo() throws Exception {
		System.out.println("QueryAllBorrowInfo()");
		List<Boob> booblist = systemservice.queryallbookbrowse();
		System.out.println("booblist : "+booblist);
		Map<String, Object> map = new HashMap<String, Object>();
		if (!booblist.isEmpty()) {
			System.out.println("!booblist.isEmpty()");
			map.put("query_borrow_status", "success");
			map.put("booblist", booblist);
		} else {
			map.put("query_borrow_status", "error");
		}
		JSONObject json = JSONObject.fromObject(map);
		borrow_result = json.toString();
		return "get_borrow_info_success";
	}
	
	public String QueryNumForAllBorrowInfo() throws Exception {
		System.out.println("QueryNumForAllBorrowInfo()");
		List<Boob> booblist = systemservice.queryallbookbrowse();
		Map<String, Object> map = new HashMap<String, Object>();
		if (!booblist.isEmpty()) {
			int size = booblist.size();
			System.out.println("QueryNumForAllBorrowInfo() GET_NUM : "+ size);
			map.put("query_num", size);
		} else {
			map.put("query_num", 0);
		}
		JSONObject json = JSONObject.fromObject(map);
		get_num_borrow_result = json.toString();
		return "get_num_for_borrow_info_success";
	}
	
}
