package xxxy.six.action;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import xxxy.six.entity.Book;
import xxxy.six.entity.Bookrack;
import xxxy.six.entity.JSON_reader;
import xxxy.six.entity.Reader;
import xxxy.six.entity.Systemer;
import xxxy.six.entity.Boob;
import xxxy.six.entity.bookbrowse;
import xxxy.six.service.BookRackService;
import xxxy.six.service.BookRackServiceimp;
import xxxy.six.service.BookService;
import xxxy.six.service.BookServiceImp;
import xxxy.six.service.ReaderService;
import xxxy.six.service.ReaderServiceImp;
import xxxy.six.service.SystemService;
import xxxy.six.service.SystemServiceimp;
import xxxy.six.util.GenerateReader;

import com.google.gson.Gson;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class ReaderAction extends ActionSupport {
	private String username;
	private String password;
	private String readbookid;
	private String name;
	private String personid;
	private String email;
	private String phone;
	private String readersex;
	private int bookid;
	private Reader reader;
	private String msg;
	private String _reader;
	private String flag;

	ActionContext context = ActionContext.getContext();
	Map<String, Object> session = context.getSession();
	ReaderService readerservice = new ReaderServiceImp();
	SystemService systemservice = new SystemServiceimp();
	BookService bookservice = new BookServiceImp();
	BookRackService bookrackservice = new BookRackServiceimp();
	
	
	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String get_reader() {
		return _reader;
	}

	public void set_reader(String _reader) {
		this._reader = _reader;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPersonid() {
		return personid;
	}

	public void setPersonid(String personid) {
		this.personid = personid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getReadersex() {
		return readersex;
	}

	public void setReadersex(String readersex) {
		this.readersex = readersex;
	}
	
	public String getMsg() {
		return msg;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public String getReadbookid() {
		return readbookid;
	}

	public void setReadbookid(String readbookid) {
		this.readbookid = readbookid;
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public Reader getReader() {
		return reader;
	}

	public void setReader(Reader reader) {
		this.reader = reader;
	}
	//���ߵĵ�¼
	public String readerlogin() throws Exception{
		System.out.println("username: "+username+" password: "+password);
		Reader user = readerservice.login(username);
		Systemer sys = null;
		if(user==null)
		{
			System.out.println("1111111111111111111111111111111111");
		    sys = systemservice.systemlogin(username, password);
		}
		if(sys!=null)
		{
			//System.out.println(sys.toString());
			session.put("username", 0);
			session.put("systemloginflag", sys.getSystemid());
			session.put("loginname", sys.getSystemname());
			System.out.println("loginname = "+session.get("loginname")+" id = "+session.get("systemloginflag"));
			return "sysloginsuccess";
		}
		else if(user!=null)
		{
			//System.out.println(user.toString());
			//System.out.println("user: "+user);
			if(user.getPassword().equals(password))
			{
				if(user.getFlag()==0)
					session.put("registflag", 1);
				if(user.getFlag()==2)
					session.put("errorflag", 1);
				session.put("username", 0);
				session.put("readloginflag", user.getReadbookid());
				session.put("loginname", user.getName());
		return "loginsuccess";
			}
		}
		session.put("username", 1);
			return "loginerror";		
	}
	//���ߵ�����
	public String readeradd() throws Exception{
		reader.setFlag(0);//û������Ϣʱ ״̬���쳣��
		//System.out.println(da);
		//SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
		//System.out.println(c.getTime());

		readerservice.add(reader);
		session.put("registflag", 1);
		return "addsuccess";
	}
	//�鿴������Ϣ(ajax)
	public String readercheckajax() throws Exception{
		Reader user = readerservice.check(reader.getId());
		System.out.println(user);
		Gson gson = new Gson();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf-8");
		String str = gson.toJson(user);
		PrintWriter writer = response.getWriter();
		writer.print(str);
		return null;
	}
	//�鿴������Ϣ
	public String readercheck() throws Exception{
		List<Reader> user = new ArrayList<Reader>();
		System.out.println("readercheck = "+readbookid);
		if(readbookid== null)
		{
			readbookid=(String) session.get("readloginflag");			
		}
		System.out.println("readercheck = "+readbookid);
		Reader us = readerservice.checkreaderbyid(readbookid);
		session.put("readerxinxi",us);
		//System.out.println(session.get("readerxinxi"));
		return "readerchecksuccess";
	}
	//�鿴����״̬
	public String readercheckflag() throws Exception{
		readerservice.checkflag(reader.getId());
		return null;
	}
	//�������
	public String borrowbook() throws Exception{
		System.out.println(readbookid+"  "+bookid);
		Boob boo = systemservice.queryboobbyid(readbookid, bookid);
		//System.out.println(boo.toString());
		session.put("jieguo", 0);
		if(boo!=null)
			if(boo.getShenhe().equals("ͬ��")||boo.getShenhe()==null)
			session.put("jieguo", 1);
		if(session.get("jieguo")!= null)
		{
			if(session.get("jieguo").toString()=="1")
			{
			Book bo = (Book) session.get("bookxinxi");
			bookid = bo.getBookid();
			Reader user = (Reader) session.get("readxinxi");
			readbookid =user.getReadbookid();
			}
		}
		Book book = readerservice.checkbookbyid(bookid);
		Reader user = readerservice.checkreaderbyid(readbookid);
		session.put("bookxinxi", book);
		session.put("readxinxi", user);
		/*System.out.println(da);
		System.out.println(s);
		System.out.println(session.get("jietime"));
		System.out.println(session.get("endtime"));*/
		return "borrowbooksuccess";
	}
	//���뵹��ʱ��ҳ���ͼ��������Ϣ����
	public String daojishiqi() throws Exception{
		System.out.println(readbookid+"   "+bookid);
		Boob bo = systemservice.queryboobbyid(readbookid, bookid);
		//System.out.println(bo.toString());
		if(bo==null)
		{
		Date da = new Date();
		System.out.println(da);
		SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
		Calendar c = Calendar.getInstance();
		System.out.println(c.getTime());
		c.add(Calendar.HOUR, 2);
		Boob boob = new Boob();
		Book book = (Book) session.get("bookxinxi");
		Reader user = (Reader) session.get("readxinxi");
		boob.setBookid(book.getBookid());
		boob.setBooklei(book.getBooklei());
		boob.setBooklocation(book.getBooklocation());
		boob.setBookname(book.getBookname());
		boob.setEmail(user.getEmail());
		boob.setReadbookid(user.getReadbookid());
		boob.setReadname(user.getName());
		boob.setPhone(user.getPhone());
		Date s = c.getTime();
		c.add(Calendar.DATE, 30);
		Date das = c.getTime();
		System.out.println("����ʱ����ʼʱ��="+da+" ����ʱ������ʱ��="+s);
		boob.setJietime(da);
		boob.setHuantime(das);
		readerservice.bookbrowseadd(boob);
		System.out.println("���ݿ⿪ʼʱ��="+da+" ���ݿ����ʱ��="+das);
		//session.put("jieshu", das)
		session.put("daojishireadbookid", user.getReadbookid());
		session.put("daojishibookid", boob.getBookid());
		session.put("jietime", da.getTime());
		session.put("endtime", s.getTime());
		session.put("jieguo", "0");
		return "daojishiqisuccess";
		}
		else
		{
			session.put("jieguo", "1");
			return "daojishiqierror";
		}
	}
	// ����ʱ��ת��ѯ���
	public String daojishiquery() throws Exception{
		readbookid = (String) session.get("daojishireadbookid");
		bookid = (Integer) session.get("daojishibookid");
		Boob boob = readerservice.queryboob(readbookid, bookid);
		if(boob.getShenhe()!=null)
		{
			if(boob.getShenhe().equals("ͬ��"))
				session.put("daojishishenhe", 1);
			else
				session.put("daojishishenhe", 2);
		}

		return "daojishiquerysuccess";
	}
	//����ɹ�
	public String borrowsuccess() throws Exception{
		Bookrack bookrack =  new Bookrack();
		bookrack.setReadbookid(readbookid);
		bookrack.setBookid(bookid);
		Boob boob = systemservice.queryboobbyid(readbookid, bookid);
		bookrack.setJietime(boob.getJietime());
		bookrack.setHuantime(boob.getHuantime());
		bookrack.setBookflag(0);
		System.out.println(bookrack.toString());
		systemservice.updateboobbyid(readbookid, bookid, "ͬ��");
		Book book = readerservice.checkbookbyid(bookid);
		Book boo = new Book();
		boo.setBookid(book.getBookid());
		boo.setBooksheng(book.getBooksheng()-1);
		boo.setBooknum(book.getBooknum());
		boo.setJienum(book.getJienum()+1);
		bookservice.bookupdate(boo);
		readerservice.borrowbook(bookrack);
		Reader read = readerservice.checkreaderbyid(readbookid);
		Reader rd = new Reader();
		rd.setReadbookid(readbookid);
		rd.setBooknum(read.getBooknum()+1);
		rd.setFlag(read.getFlag());
		readerservice.readerupdate(rd);
		return "borrowsuccess";
	}
	//����ʧ��
	public String borrowerror() throws Exception{
		session.put("jietime", null);
		session.put("endtime", null);
		systemservice.updateboobbyid(readbookid, bookid, "�ܾ�");
		//session.put("jietime", null);
		return "borrowerror";
	}
	//���蹦��(ԭ���鹦��)
	public String giveback() throws Exception{
		//����
		Bookrack bookrack = bookrackservice.querybookrackbyid(readbookid, bookid);
		Boob bb = new Boob();
		Date da = bookrack.getHuantime();
		System.out.println("��ǰ������:"+da);
		Calendar ca = Calendar.getInstance();
		ca.setTime(da);
		System.out.println("ca������"+ca.getTime());
		ca.add(Calendar.DATE, 7);
		da = ca.getTime();
		System.out.println("�Ӻ������:"+da);
		Bookrack boo = new Bookrack();
		boo.setReadbookid(readbookid);
		boo.setBookflag(1);
		boo.setBookid(bookid);
		boo.setHuantime(da);
		bb.setBookid(bookid);
		bb.setReadbookid(readbookid);
		bb.setHuantime(da);
		systemservice.updateboob(bb);
		bookrackservice.updatebookrack(boo);
		session.put("zbookrackflag", readbookid);
		return "givebacksuccess";
	}
	//�޸Ķ�����Ϣ
	public String readerupdate() throws Exception{
		reader.setFlag(1);
		//��ֹ��������
		byte[] b=reader.getName().getBytes("ISO-8859-1");//��tomcat�ĸ�ʽ��iso-8859-1����ʽȥ����
		String str=new String(b,"utf-8");
		reader.setName(str);
		byte[] yt = reader.getReadersex().getBytes("ISO-8859-1");
		String sr = new String(yt,"utf-8");
		reader.setReadersex(sr);
		
		//���Ӷ���֤��ʼ����
		Date da = new Date();
		reader.setRecorddate(da);
		//���Ӷ���֤��������
		Calendar c = Calendar.getInstance();
		c.add(Calendar.YEAR, 2);
		Date d = c.getTime();
		reader.setValiduntil(d);
		//----------------------
		//reader.setBooknum(0);
		//System.out.println("readupdate = "+reader.toString());
		readerservice.readerupdate(reader);
		session.put("registflag", 0);
		return "readerupdatesuccess";
	}

	//����Ա���Ӷ���
	public String readeraddbyadmin() throws Exception{
		Date recorddate = new Date();
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(recorddate);
		calendar.add(calendar.YEAR, 4);
		Date validuntil = calendar.getTime();
		Reader r = new Reader(
				readbookid,
				password,
				name,
				readersex,
				personid,
				phone,
				email,
				1,	//flag
				recorddate,
				validuntil,
				0	//booknum
			);
		System.out.println("readeraddbyadmin : " + r);
		readerservice.admin_add_reader(r);
		Gson gson = new Gson();
		msg = gson.toJson("true");
		return "readeraddbyadmin";
	}
	
	//���ɶ��߲�����Ϣ
	public String readergenerated() throws Exception{
		GenerateReader GR = new GenerateReader();
		JSON_reader json_reader = GR.generateReader();
		Gson gson = new Gson();
		_reader = gson.toJson(json_reader);
		return "readergenerated";
	}

	//�û��ǳ�
	public String out() throws Exception{
		session.put("readloginflag", null);
		session.put("systemloginflag", null);
		session.put("loginname", null);
		session.put("errorflag", 0);
		session.put("registflag", 0);
		return "outsuccess";
	}
}
