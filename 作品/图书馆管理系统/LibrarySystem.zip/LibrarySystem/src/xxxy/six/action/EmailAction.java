package xxxy.six.action;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;

import xxxy.six.email.EmailUtil;
import xxxy.six.email.SendEmail;
import xxxy.six.entity.Reader;
import xxxy.six.entity.Systemer;
import xxxy.six.entity.VerifyCode;
import xxxy.six.service.ReaderService;
import xxxy.six.service.ReaderServiceImp;
import xxxy.six.service.SystemService;
import xxxy.six.service.SystemServiceimp;
import xxxy.six.service.VerifyCodeService;
import xxxy.six.service.VerifyCodeServiceimp;

import com.opensymphony.xwork2.ActionSupport;

public class EmailAction extends ActionSupport{
	private String username;
	private String email;
	private String verifycode;
	private String password;
	private String result;
	
	
	public String getVerifycode() {
		return verifycode;
	}
	public void setVerifycode(String verifycode) {
		this.verifycode = verifycode;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	ReaderService readerservice = new ReaderServiceImp();
	SystemService systemservice = new SystemServiceimp();
	VerifyCodeService vcodeservice = new VerifyCodeServiceimp(); 
	EmailUtil emailUtil = new EmailUtil();
	
	public String updatesuccess() throws Exception{
		//��ȡ�û���
		return "success";
	}
	public String forget() throws Exception{
		
		return "success";
	}
	public String SendEmail() throws Exception{
		System.out.println("ACTION: SendEmail()");
		Reader reader = readerservice.queryReaderIsExistByUsername(username);
		String res = "";
		if(reader != null) {
			String email = reader.getEmail();
			if(email != null){
				String emailCode = SendEmail.createCode();
				System.out.println("ACTION: forget()  ��ȡ����Code:"+emailCode);
				Boolean sendSuccess = emailUtil.EmailContent(reader.getName(), email, emailCode);
				res = ( sendSuccess == true ? "sendEmailSuccess" : "sendEmailError");
				if(sendSuccess){
					Date createtime = new Date();
					Integer status = 0;
					VerifyCode vcode = new VerifyCode(emailCode, reader.getReadbookid(), email, createtime, status);
					vcodeservice.generateCode(vcode);
				}
			}
			else{
				res = "userNotBindEmail";				
			}
		} else {
			res =  "userNotExisted";			
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("sendmsg", res);
		System.out.println(res);
		JSONObject json = JSONObject.fromObject(map);
		result = json.toString();
		return "has_send";
	}
	public String update() throws Exception{
		String res = "";
		VerifyCode code = vcodeservice.queryVerifyCode(verifycode, username);
		if(code != null){
			readerservice.updateReaderPasswdByReadbookid(code.getUsername(),password);
			res = "update_success";
		} else {
			res = "update_error";
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("updatemsg", res);
		System.out.println(res);
		JSONObject json = JSONObject.fromObject(map);
		result = json.toString();
		return "has_update";
	}
}
