package xxxy.six.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import xxxy.six.entity.Book;
import xxxy.six.service.BookService;
import xxxy.six.service.BookServiceImp;
import xxxy.six.service.ReaderService;
import xxxy.six.service.ReaderServiceImp;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class BookAction extends ActionSupport {
private Book book;
private String name;
private File file;
private int lai;
private int bookid;
private int num;


public int getNum() {
	return num;
}

public void setNum(int num) {
	this.num = num;
}

public int getBookid() {
	return bookid;
}

public void setBookid(int bookid) {
	this.bookid = bookid;
}

public int getLai() {
	return lai;
}

public void setLai(int lai) {
	this.lai = lai;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public File getFile() {
	return file;
}

public void setFile(File file) {
	this.file = file;
}

public String getFileFileName() {
	return fileFileName;
}

public void setFileFileName(String fileFileName) {
	this.fileFileName = fileFileName; 
}
private String fileFileName; // input name + "FileName"
ActionContext context = ActionContext.getContext();
Map<String, Object> session = context.getSession();
BookService bookservice = new BookServiceImp();
ReaderService readerservice = new ReaderServiceImp();
public Book getBook() {
	return book;
}

public void setBook(Book book) {
	this.book = book;
}
//ͼ�������
public String bookadd() throws Exception{
	//ͼƬ���Ӵ���
	if(fileFileName!=null){
		String path = ServletActionContext.getServletContext().getRealPath("/upload");
		InputStream in = new FileInputStream(this.file);
		OutputStream out = new FileOutputStream(path+"\\"+this.fileFileName);
		int len = 0;
		byte[] by = new byte[1024];
		while((len=in.read(by))>0){
			out.write(by,0,len);
		}
		in.close();
		out.close();
		book.setFilename(this.fileFileName);
		book.setBookurl(path);
	}
	//------�ָ���------
	//����ͼ�������
	Date da = new Date();
	book.setBooktime(da);
	//------�ָ���------

	book.setBooksheng(book.getBooknum());
	bookservice.bookadd(book);
	return "booksuccess";
}
//��ѯ����ͼ��
public String queryallbook() throws Exception{
	List<Integer> shu=null;
	session.put("querybook", null);
	Integer paiming=1;
	List<Book> listbook = bookservice.queryallbook();
	//��ȡͼ���鲿��
	for (int i=0;i<listbook.size();i++) {
		Book boo = listbook.get(i);
		boo.setPaiming(paiming++);
		if(boo.getBookcontent().length()>37)
		boo.setBookcontent(boo.getBookcontent().substring(0, 37)+"...");
		else
			boo.setBookcontent(boo.getBookcontent());
		listbook.set(i, boo);
	}
	//------�ָ���------
	
	session.put("listbook", listbook);
	session.put("mapaiming", paiming-1);
	return "queryallbooksuccess";
}
//��ѯͼ����Ϣ ������ı�� ģ����ѯ 
public String querybookbyid() throws Exception{
	System.out.println(name);
	System.out.println("ll"+lai);
	if(lai==1)
		{
		byte[] b=name.getBytes("ISO-8859-1");//��tomcat�ĸ�ʽ��iso-8859-1����ʽȥ����
		String str=new String(b,"utf-8");
		name=str;
		System.out.println("lai = "+name);
		}
	List<Book> listbook = bookservice.querybookbystr(name);
	System.out.println("wawawaw "+ listbook);
	Integer paiming=1;
	for (int i=0;i<listbook.size();i++) {
		Book boo = listbook.get(i);
		boo.setPaiming(paiming++);
		if(boo.getBookcontent().length()>37)
		boo.setBookcontent(boo.getBookcontent().substring(0, 37)+"...");
		else
			boo.setBookcontent(boo.getBookcontent());
		listbook.set(i, boo);
	}
	session.put("querybook", listbook);
	return "querybookidsuccess";
}
//�޸�ͼ����Ϣ
public String updatebooknum() throws Exception{
	int id = bookid;
	int shu = num;
	Book book = new Book();
	Book boo = readerservice.checkbookbyid(id);
	int s = boo.getBooknum();
	int ss = boo.getBooksheng();
	book.setBookid(id);
	book.setBooknum(s+num);
	book.setBooksheng(ss+num);
	System.out.println("update = "+book.toString());
	bookservice.bookupdate(book);
	return "updatebooknumsuccess";
}
public String updatebooknumj() throws Exception{
	int id = bookid;
	int shu = num;
	Book book = new Book();
	Book boo = readerservice.checkbookbyid(id);
	int zong = boo.getBooknum();
	int sheng = boo.getBooksheng();
	if(num>sheng)
	{
		zong-=sheng;
		sheng=0;
	}
	else
	{
		zong-=num;
		sheng-=num;
	}
	book.setBookid(id);
	book.setBooknum(zong);
	book.setBooksheng(sheng);
	System.out.println("update = "+book.toString());
	if(zong!=0)
	bookservice.bookupdate(book);

	return "updatebooknumjsuccess";
}
}
