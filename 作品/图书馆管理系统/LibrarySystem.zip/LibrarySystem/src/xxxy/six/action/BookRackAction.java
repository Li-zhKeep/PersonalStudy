package xxxy.six.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import xxxy.six.entity.Book;
import xxxy.six.entity.Bookrack;
import xxxy.six.entity.Bookrackextend;
import xxxy.six.service.BookRackService;
import xxxy.six.service.BookRackServiceimp;
import xxxy.six.service.BookService;
import xxxy.six.service.BookServiceImp;
import xxxy.six.service.ReaderService;
import xxxy.six.service.ReaderServiceImp;

public class BookRackAction extends ActionSupport {
	ReaderService readerservice = new ReaderServiceImp();
	BookRackService bookrackservice = new BookRackServiceimp();
	ActionContext context = ActionContext.getContext();
	Map<String, Object> session = context.getSession();
	private Bookrack bookrack;
	private String readbookid;
	
	public String getReadbookid() {
		return readbookid;
	}
	public void setReadbookid(String readbookid) {
		this.readbookid = readbookid;
	}
	public Bookrack getBookrack() {
		return bookrack;
	}
	public void setBookrack(Bookrack bookrack) {
		this.bookrack = bookrack;
	}
	//��ѯ�������
	public String querybookrack() throws Exception{
		if(readbookid==null)
			readbookid = (String) session.get("readloginflag");
		List<Bookrack> listbookrack = bookrackservice.querybookrack(readbookid);
		//����(����ʱ��)
		Collections.sort(listbookrack, new Comparator<Bookrack>() {

			public int compare(Bookrack o1, Bookrack o2) {
				
				return o2.getJietime().compareTo(o1.getJietime());
			}
		});
		List<Bookrackextend> zlistbookrackextend = new ArrayList<Bookrackextend>();
		List<Bookrackextend> ylistbookrackextend = new ArrayList<Bookrackextend>();
		//List<Book> listbook = new ArrayList<Book>();
		int paiming=1,ypaiming=1;
		for(int i=0;i<listbookrack.size();i++)
		{

			Book book = readerservice.checkbookbyid(listbookrack.get(i).getBookid());
			if(listbookrack.get(i).getBookflag()==0||listbookrack.get(i).getBookflag()==1)
			{
			Bookrackextend bookrackextend = new Bookrackextend(paiming++,book.getBookid(),book.getBookname(), listbookrack.get(i).getJietime(), listbookrack.get(i).getHuantime(), book.getBookauthor(), book.getChubanshe(), listbookrack.get(i).getBookflag(), book.getBookurl(), book.getBookcontent(),book.getBooklei());
			zlistbookrackextend.add(bookrackextend);
			}
			else
			{
				Bookrackextend bookrackextend = new Bookrackextend(ypaiming++,book.getBookid(),book.getBookname(), listbookrack.get(i).getJietime(), listbookrack.get(i).getHuantime(), book.getBookauthor(), book.getChubanshe(), listbookrack.get(i).getBookflag(), book.getBookurl(), book.getBookcontent(),book.getBooklei());
				ylistbookrackextend.add(bookrackextend);
					
			}
			//listbook.add(book);
			//System.out.println(bookrackextend.toString());
		}
		System.out.println("zbookracklist = "+zlistbookrackextend);
		System.out.println("ybookracklist = "+ylistbookrackextend);
		session.put("zbookracklist", zlistbookrackextend);
		session.put("ybookracklist", ylistbookrackextend);
		//session.put("bookracklist", listbookrack);
		//session.put("bookracklistbook", listbook);
		return "querybookracksuccess";
	}
	//ɾ������еļ�¼
	public String deletebookrack() throws Exception{
		
		return "deletebookracksuccess";
	}
}
