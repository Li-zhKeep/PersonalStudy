package xxxy.six.action;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import xxxy.six.email.EmailUtil;
import xxxy.six.entity.Boob;
import xxxy.six.entity.Book;
import xxxy.six.entity.Bookrack;
import xxxy.six.entity.Reader;
import xxxy.six.entity.Systemer;
import xxxy.six.service.BookRackService;
import xxxy.six.service.BookRackServiceimp;
import xxxy.six.service.BookService;
import xxxy.six.service.ReaderService;
import xxxy.six.service.ReaderServiceImp;
import xxxy.six.service.SystemService;
import xxxy.six.service.SystemServiceimp;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;


public class SystemAction extends ActionSupport {

	SystemService systemservice = new SystemServiceimp();
	ActionContext context = ActionContext.getContext();
	Map<String, Object> session = context.getSession();
	private Systemer systemer;
	BookRackService bookrackservice = new BookRackServiceimp();
	ReaderService readerservice = new ReaderServiceImp();
	String readbookid;
	int bookid;
	
	public String getReadbookid() {
		return readbookid;
	}
	public void setReadbookid(String readbookid) {
		this.readbookid = readbookid;
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public Systemer getSystemer() {
		return systemer;
	}
	public void setSystemer(Systemer systemer) {
		this.systemer = systemer;
	}
	//��ѯ���ж�����Ϣ
	public String queryallreader() throws Exception{
		List<Reader> list = systemservice.queryallreader();
		List<Boob> booblist = systemservice.queryallbookbrowse();
		session.put("allreader", list);
		session.put("allboob", booblist);
		return "queryallreadersuccess";
	}
	//����Ա������
	public String systemadd() throws Exception{
		systemservice.systemadd(systemer);
		return "systemaddsuccess";
	}
	//����Ա���ڲ���
	public String giveback() throws Exception{
		Bookrack bookrack = bookrackservice.querybookrackbyid(readbookid, bookid);
		Boob bb = new Boob();
		Date da = bookrack.getHuantime();
		System.out.println("��ǰ������:"+da);
		Calendar ca = Calendar.getInstance();
		ca.setTime(da);
		System.out.println("ca������"+ca.getTime());
		ca.add(Calendar.DATE, 7);
		da = ca.getTime();
		System.out.println("�Ӻ������:"+da);
		Bookrack boo = new Bookrack();
		boo.setReadbookid(readbookid);
		boo.setBookflag(1);
		boo.setBookid(bookid);
		boo.setHuantime(da);
		bb.setBookid(bookid);
		bb.setReadbookid(readbookid);
		bb.setHuantime(da);
		systemservice.updateboob(bb);
		bookrackservice.updatebookrack(boo);
		session.put("zbookrackflag", readbookid);
		return "giveback";
	}
	//����Ա����
	public String huan() throws Exception{
		Bookrack bookrack = bookrackservice.querybookrackbyid(readbookid, bookid);
		Book bk = readerservice.checkbookbyid(bookid);
		Book book = new Book();
		book.setBookid(bookid);
		int num = bk.getBooksheng();
		book.setBooksheng(num+1);
		systemservice.updatebook(book);
		Boob bb = new Boob();
		bb.setBookid(bookid);
		bb.setReadbookid(readbookid);
		Bookrack rack = new Bookrack();
		rack.setBookid(bookid);
		rack.setReadbookid(readbookid);
		rack.setBookflag(2);
		bookrackservice.updatebookrack(rack);
		systemservice.deleteboob(bb);
		return "huansuccess";
	}
	//���¶���״̬
	public String gengxin() throws Exception{
		Date da = new Date();
		session.put("errorflag", 0);
		List<Bookrack> listrack = systemservice.queryallbookrack();
		List<Reader> liststr = new ArrayList<Reader>();
		List<Reader> listread  = systemservice.queryallreader();
		//List<Reader> llread = new ArrayList<Reader>();
		for (Reader reader : listread) {
			if(reader.getFlag()==2)
			{
				reader.setFlag(1);
				//llread.add(reader);
				systemservice.updatereader(reader);
			}
		}
		for (Bookrack bookrack : listrack) {
			Date d = bookrack.getHuantime();
			if(d.before(da)&& bookrack.getBookflag()!=2)
			{
				Reader read = new Reader();
				boolean flag = true;
				for (Reader string : liststr) {
					if(bookrack.getReadbookid().equals(string.getReadbookid()))
					{
						flag=false;
						break;
					}
				}
				if(flag)
				{
					Reader rr = readerservice.checkreaderbyid(bookrack.getReadbookid());
					read.setReadbookid(rr.getReadbookid());
					read.setFlag(2);
					read.setEmail(rr.getEmail());
					read.setName(rr.getName());
					liststr.add(read);
				}
			}
		}
		for (Reader reader : liststr) {
			System.out.println("----------------123123213---------------------------");
			systemservice.updatereader(reader);
			EmailUtil emailUtil = new EmailUtil();
			String _username = reader.getName();
			String _email = reader.getEmail();
			Boolean emailContent = emailUtil.EmailContent(_username, _email);
			System.out.println("EmailUtil : "+emailContent);
		}
		return "gengsuccess";
	}
}
