package xxxy.six.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import xxxy.six.entity.Reader;
import xxxy.six.service.ReaderService;
import xxxy.six.service.ReaderServiceImp;

import com.opensymphony.xwork2.ActionSupport;

public class CheckAction extends ActionSupport{
	
	ReaderService readerservice = new ReaderServiceImp();
	private String result;
	private String username;
	
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}


	public String CheckUsername() throws Exception{	
		String INFO = "ACTION CheckUsername : ";
		System.out.println(INFO+" BEGIN ");
		System.out.println(INFO+"username:"+username);
		
		Reader r = readerservice.queryReaderIsExistByUsername(username);
		int flag = (r == null ? 1 : 0);
		Map<String, Object> map = new HashMap<String, Object>();
		if(flag == 0){
			System.out.println(INFO+" END [with username_exits]");			
			map.put("flag","has_exits");			
		} else {
			System.out.println(INFO+" END [with username_not_exits]");
			map.put("flag","not_exits");			
		}	

		JSONObject json = JSONObject.fromObject(map);
		result = json.toString();
		return "check_username_over";
	}

}
