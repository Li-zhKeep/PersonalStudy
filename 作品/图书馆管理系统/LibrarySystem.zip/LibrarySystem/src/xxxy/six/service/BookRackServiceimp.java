package xxxy.six.service;

import java.util.List;

import xxxy.six.dao.BookRackDAO;
import xxxy.six.entity.Bookrack;
import xxxy.six.util.GetSqlSession;

public class BookRackServiceimp implements BookRackService {

	BookRackDAO bookrackdao = GetSqlSession.get().getMapper(BookRackDAO.class);
	//��ѯ�������
	public List<Bookrack> querybookrack(String readbookid) throws Exception {
		List<Bookrack> list = bookrackdao.querybookrack(readbookid);
		return list;
	}
	//��ѯ����е�һ����
	public Bookrack querybookrackbyid(String readbookid, int bookid)
			throws Exception {
		Bookrack bookrack = bookrackdao.querybookrackbyid(readbookid, bookid);
		return bookrack;
	}
	public void updatebookrack(Bookrack bookrack) throws Exception {
		bookrackdao.updatebookrack(bookrack);
		GetSqlSession.commit();
	}
	public void deletebookrack(String readbookid, int bookid) throws Exception {
		bookrackdao.deletebookrack(readbookid, bookid);
	}
	
}
