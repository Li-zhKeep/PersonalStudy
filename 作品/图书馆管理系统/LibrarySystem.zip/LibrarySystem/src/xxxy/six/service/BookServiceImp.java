package xxxy.six.service;

import java.util.List;

import xxxy.six.dao.BookDAO;
import xxxy.six.entity.Book;
import xxxy.six.util.GetSqlSession;

public class BookServiceImp implements BookService {
	BookDAO bookdao = GetSqlSession.get().getMapper(BookDAO.class);
	//����ͼ��
	public void bookadd(Book book) throws Exception {
		bookdao.bookadd(book);
		GetSqlSession.commit();
	}
	//��ѯ����ͼ��
	public List<Book> queryallbook() throws Exception {
		List<Book> listbook = bookdao.queryallbook();
		return listbook;
	}
	//��ѯͼ�����ͼ������(ģ����ѯ)
	public List<Book> querybookbystr(String name) throws Exception {
		System.out.println("service = "+name);
		List<Book> listbook = bookdao.querybookbystr(name,name);
		return listbook;
	}
	//�޸�ͼ��
	public void bookupdate(Book book) throws Exception {
		System.out.println("book="+book.toString());
		bookdao.bookupdate(book);
		GetSqlSession.commit();
	}
	//����ʱ�в�ѯ��������״̬
	public String yi(String readbookid, int bookid) throws Exception {
		String flag=null;
		flag=bookdao.yi(readbookid, bookid);
		return flag;
	}
	@Override
	public void bookdelete(int id) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
}
