package xxxy.six.service;

import java.util.List;

import xxxy.six.dao.SystemDAO;
import xxxy.six.entity.Book;
import xxxy.six.entity.Bookrack;
import xxxy.six.entity.Reader;
import xxxy.six.entity.Systemer;
import xxxy.six.entity.Boob;
import xxxy.six.util.GetSqlSession;

public class SystemServiceimp implements SystemService{

	SystemDAO sysytemdao = GetSqlSession.get().getMapper(SystemDAO.class);
	public void systemadd(Systemer systemer) throws Exception {
		sysytemdao.systemadd(systemer);
		GetSqlSession.commit();
	}


	public void systemerupdate(Systemer systemer) throws Exception {
		
	}

	public List<Reader> queryallreader() throws Exception {
		List<Reader> list = sysytemdao.queryallreader();
		return list;
	}


	public List<Boob> queryallbookbrowse() throws Exception {
		List<Boob> list = sysytemdao.queryallbookbrowse();
		return list;
	}


	public Systemer systemlogin(String systemid, String password)
			throws Exception {
		Systemer sys = sysytemdao.systemlogin(systemid, password);
		return sys;
	}


	public Systemer querySystemerIsExistByUsername(String username) {
		Systemer systemer = sysytemdao.querySystemerIsExistByUsername(username);
		return systemer;
	}


	public Boob queryboobbyid(String readbookid, int bookid) throws Exception {
		Boob boob = sysytemdao.queryboobbyid(readbookid, bookid);
		//System.out.println("���� = "+boob.toString());
		return boob;
	}


	public void updateboobbyid(String readbookid, int bookid, String shenhe)
			throws Exception {
		sysytemdao.updateboobbyid(readbookid, bookid, shenhe);
		GetSqlSession.commit();
	}


	public void updateboob(Boob boob) throws Exception {
		sysytemdao.updateboob(boob);
		GetSqlSession.commit();
	}


	public void deleteboob(Boob boob) throws Exception {
		sysytemdao.deleteboob(boob);
		GetSqlSession.commit();
	}


	public void updatebook(Book book) throws Exception {
		sysytemdao.updatebook(book);
		GetSqlSession.commit();
	}


	public List<Bookrack> queryallbookrack() throws Exception {
		List<Bookrack> list = sysytemdao.queryallbookrack();
		return list;
	}


	public void updatereader(Reader list) throws Exception {
		sysytemdao.updatereader(list);
		GetSqlSession.commit();
	}

}
