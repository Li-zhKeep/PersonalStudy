package xxxy.six.service;


import java.util.List;

import javax.ws.rs.GET;

import xxxy.six.dao.ReaderDAO;
import xxxy.six.entity.Book;
import xxxy.six.entity.Bookrack;
import xxxy.six.entity.Reader;
import xxxy.six.entity.Boob;
import xxxy.six.util.GetSqlSession;

public class ReaderServiceImp implements ReaderService {
	ReaderDAO readerdao = GetSqlSession.get().getMapper(ReaderDAO.class);
	//��¼
	public Reader login(String username) throws Exception {
		Reader reader = null;
		reader = readerdao.login(username);
		return reader;
	}
	//ע��
	public void add(Reader reader) throws Exception {
		readerdao.add(reader);
		GetSqlSession.commit();
	}
	//�鿴������Ϣ
	public Reader check(int id) throws Exception {
		Reader reader = null;
		reader = readerdao.check(id);
		return reader;
	}

	//�鿴����״̬
	public int checkflag(int id) throws Exception {
		return readerdao.checkflag(id);
	}
	//���߽���
	public void borrowbook(Bookrack bookrack) throws Exception {
		readerdao.borrowbook(bookrack);
		GetSqlSession.commit();
	}
	//��ѯ���߸�����Ϣ
	public Reader checkreaderbyid(String readbookid) throws Exception {
		return readerdao.checkreaderbyid(readbookid);
	}
	//��ѯͼ����Ϣ
	public Book checkbookbyid(int bookid) throws Exception {
		return readerdao.checkbookbyid(bookid);
	}
	//�޸ĸ�����Ϣ
	public void readerupdate(Reader reader) throws Exception {
		readerdao.readerupdate(reader);
		GetSqlSession.commit();
	}
	//��ѯ�����Ƿ���� ͨ���û���
	public Reader queryReaderIsExistByUsername(String username)
			throws Exception {
		// TODO Auto-generated method stub
		Reader reader = readerdao.queryReaderIsExistByUsername(username);
		return reader;
	}
	//�������� ͨ���û�����������֤��
	public void updateReaderPasswdByReadbookid(String readbookid,String password) throws Exception {
		// TODO Auto-generated method stub
		readerdao.updateReaderPasswdByReadbookid(readbookid,password);
		GetSqlSession.commit();
	}
	// ͼ�������������
	public void bookbrowseadd(Boob boob) throws Exception {
		readerdao.bookbrowseadd(boob);
		GetSqlSession.commit();
	}
	//
	public void giveback(Book book) throws Exception {
		readerdao.giveback(book);
		GetSqlSession.commit();
		
	}
	//
	public void updatebookrack(Bookrack bookrack) throws Exception {
		readerdao.updatebookrack(bookrack);
		GetSqlSession.commit();
	}
	//��ѯ����ȫ����Ϣ
	@Override
	public List<Reader> queryAllReaderInfo() {
		List<Reader> list = readerdao.queryAllReaderInfo();
		System.out.println("size="+list.size());
		return list;
	}
	//����Ա�����û�
	public void admin_add_reader(Reader reader) throws Exception {
		// TODO Auto-generated method stub
		readerdao.admin_add_reader(reader);
		GetSqlSession.commit();
	}
	public Boob queryboob(String readbookid, int bookid) throws Exception {
		Boob boob = readerdao.queryboob(readbookid, bookid);
		return boob;
	}
}
