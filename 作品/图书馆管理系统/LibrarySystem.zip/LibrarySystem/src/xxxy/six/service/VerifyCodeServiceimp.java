package xxxy.six.service;

import java.util.List;

import xxxy.six.dao.VerifyCodeDao;
import xxxy.six.entity.Bookrack;
import xxxy.six.entity.VerifyCode;
import xxxy.six.util.GetSqlSession;

public class VerifyCodeServiceimp implements VerifyCodeService {
	VerifyCodeDao vcodeDao = GetSqlSession.get().getMapper(VerifyCodeDao.class);

	@Override
	public void generateCode(VerifyCode vcode) throws Exception {
		// TODO Auto-generated method stub
		vcodeDao.generateCode(vcode);
		GetSqlSession.commit();
	}

	@Override
	public VerifyCode queryVerifyCode(String verifycode, String username) {
		// TODO Auto-generated method stub
		VerifyCode code = vcodeDao.queryVerifyCode(verifycode, username);
		return code;
	}
}
