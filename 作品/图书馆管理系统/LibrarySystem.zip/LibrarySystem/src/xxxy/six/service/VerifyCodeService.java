package xxxy.six.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import xxxy.six.entity.Bookrack;
import xxxy.six.entity.VerifyCode;

public interface VerifyCodeService {

	public void generateCode(VerifyCode vcode) throws Exception;
	
	public VerifyCode queryVerifyCode(String verifycode,String username);
}
