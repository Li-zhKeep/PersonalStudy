package xxxy.six.dao;

import org.apache.ibatis.annotations.Param;

import xxxy.six.entity.VerifyCode;


public interface VerifyCodeDao {
	public void generateCode(VerifyCode vcode);
	public VerifyCode queryVerifyCode(@Param("verifycode")String verifycode,@Param("username")String username);
}
