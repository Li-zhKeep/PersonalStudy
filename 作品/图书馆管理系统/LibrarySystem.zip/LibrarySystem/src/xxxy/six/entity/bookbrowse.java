package xxxy.six.entity;

public class bookbrowse {
private String readbookid;
private String readname;
private String readpassword;
private String phone;
private String email;
private String bookname;
private String bookid;
private String shenhe;
private String flag;
private String beizhu;
public String getReadbookid() {
	return readbookid;
}
public void setReadbookid(String readbookid) {
	this.readbookid = readbookid;
}
public String getReadname() {
	return readname;
}
public void setReadname(String readname) {
	this.readname = readname;
}
public String getReadpassword() {
	return readpassword;
}
public void setReadpassword(String readpassword) {
	this.readpassword = readpassword;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public String getBookid() {
	return bookid;
}
public void setBookid(String bookid) {
	this.bookid = bookid;
}
public String getShenhe() {
	return shenhe;
}
public void setShenhe(String shenhe) {
	this.shenhe = shenhe;
}
public String getFlag() {
	return flag;
}
public void setFlag(String flag) {
	this.flag = flag;
}
public String getBeizhu() {
	return beizhu;
}
public void setBeizhu(String beizhu) {
	this.beizhu = beizhu;
}
public bookbrowse(String readbookid, String readname, String readpassword,
		String phone, String email, String bookname, String bookid,
		String shenhe, String flag, String beizhu) {
	super();
	this.readbookid = readbookid;
	this.readname = readname;
	this.readpassword = readpassword;
	this.phone = phone;
	this.email = email;
	this.bookname = bookname;
	this.bookid = bookid;
	this.shenhe = shenhe;
	this.flag = flag;
	this.beizhu = beizhu;
}
public bookbrowse() {
	super();
}
public bookbrowse(String readbookid, String readname, String readpassword,
		String phone, String email, String bookname, String shenhe) {
	super();
	this.readbookid = readbookid;
	this.readname = readname;
	this.readpassword = readpassword;
	this.phone = phone;
	this.email = email;
	this.bookname = bookname;
	this.shenhe = shenhe;
}
@Override
public String toString() {
	return "bookbrowse [readbookid=" + readbookid + ", readname=" + readname
			+ ", readpassword=" + readpassword + ", phone=" + phone
			+ ", email=" + email + ", bookname=" + bookname + ", bookid="
			+ bookid + ", shenhe=" + shenhe + ", flag=" + flag + ", beizhu="
			+ beizhu + "]";
}

}
