package xxxy.six.entity;

import java.util.Date;

public class Boob {
private String readbookid;
private String readname;
private String password;
private String phone;
private String email;
private String bookname;
private int bookid;
private Date jietime;
private Date huantime;
private String shenhe;
private String flag;
private String beizhu;
private String booklei;
private String booklocation;

public Date getJietime() {
	return jietime;
}
public void setJietime(Date jietime) {
	this.jietime = jietime;
}
public Date getHuantime() {
	return huantime;
}
public void setHuantime(Date huantime) {
	this.huantime = huantime;
}
public String getReadbookid() {
	return readbookid;
}
public void setReadbookid(String readbookid) {
	this.readbookid = readbookid;
}
public String getReadname() {
	return readname;
}
public void setReadname(String readname) {
	this.readname = readname;
}

public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public int getBookid() {
	return bookid;
}
public void setBookid(int bookid) {
	this.bookid = bookid;
}
public String getShenhe() {
	return shenhe;
}
public void setShenhe(String shenhe) {
	this.shenhe = shenhe;
}
public String getFlag() {
	return flag;
}
public void setFlag(String flag) {
	this.flag = flag;
}
public String getBeizhu() {
	return beizhu;
}
public void setBeizhu(String beizhu) {
	this.beizhu = beizhu;
}

public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getBooklei() {
	return booklei;
}
public void setBooklei(String booklei) {
	this.booklei = booklei;
}
public String getBooklocation() {
	return booklocation;
}
public void setBooklocation(String booklocation) {
	this.booklocation = booklocation;
}
public Boob() {
	super();
}

public Boob(String readbookid, String readname, String phone,
		String email, String bookname, int bookid, String booklei,
		String booklocation) {
	super();
	this.readbookid = readbookid;
	this.readname = readname;
	this.phone = phone;
	this.email = email;
	this.bookname = bookname;
	this.bookid = bookid;
	this.booklei = booklei;
	this.booklocation = booklocation;
}

public Boob(String readbookid, String readname, String password,
		String phone, String email, String bookname, int bookid, Date jietime,
		Date huantime, String shenhe, String flag, String beizhu,
		String booklei, String booklocation) {
	super();
	this.readbookid = readbookid;
	this.readname = readname;
	this.password = password;
	this.phone = phone;
	this.email = email;
	this.bookname = bookname;
	this.bookid = bookid;
	this.jietime = jietime;
	this.huantime = huantime;
	this.shenhe = shenhe;
	this.flag = flag;
	this.beizhu = beizhu;
	this.booklei = booklei;
	this.booklocation = booklocation;
}
@Override
public String toString() {
	return "bookbrowse [readbookid=" + readbookid + ", readname=" + readname
			+ ", password=" + password + ", phone=" + phone + ", email="
			+ email + ", bookname=" + bookname + ", bookid=" + bookid
			+ ", jietime=" + jietime + ", huantime=" + huantime + ", shenhe="
			+ shenhe + ", flag=" + flag + ", beizhu=" + beizhu + ", booklei="
			+ booklei + ", booklocation=" + booklocation + "]";
}

}
