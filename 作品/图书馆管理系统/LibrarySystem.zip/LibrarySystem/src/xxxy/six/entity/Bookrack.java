package xxxy.six.entity;

import java.util.Date;

import javax.xml.crypto.Data;

public class Bookrack implements Comparable<Bookrack> {
	private int id;
	private String readbookid;
	private int bookid;
	private Date jietime;
	private Date huantime;
	private int bookflag;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getReadbookid() {
		return readbookid;
	}

	public void setReadbookid(String readbookid) {
		this.readbookid = readbookid;
	}



	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public Date getJietime() {
		return jietime;
	}

	public void setJietime(Date jietime) {
		this.jietime = jietime;
	}

	public Date getHuantime() {
		return huantime;
	}

	public void setHuantime(Date huantime) {
		this.huantime = huantime;
	}

	public int getBookflag() {
		return bookflag;
	}

	public void setBookflag(int bookflag) {
		this.bookflag = bookflag;
	}

	public Bookrack(String readbookid, int bookid, Date jietiem,
			Date huantime, int bookflag) {
		super();
		this.readbookid = readbookid;
		this.bookid = bookid;
		this.jietime = jietiem;
		this.huantime = huantime;
		this.bookflag = bookflag;
	}

	public Bookrack(int id, String readbookid, int bookid, Date jietiem,
			Date huantime, int bookflag) {
		super();
		this.id = id;
		this.readbookid = readbookid;
		this.bookid = bookid;
		this.jietime = jietiem;
		this.huantime = huantime;
		this.bookflag = bookflag;
	}

	public Bookrack() {
		super();
	}

	public String toString() {
		return "Bookrack [id=" + id + ", readbookid=" + readbookid
				+ ", bookid=" + bookid + ", jietime=" + jietime + ", huantime="
				+ huantime + ", bookflag=" + bookflag + "]";
	}

	public int compareTo(Bookrack o) {
		return this.jietime.compareTo(o.jietime);
	}

}
