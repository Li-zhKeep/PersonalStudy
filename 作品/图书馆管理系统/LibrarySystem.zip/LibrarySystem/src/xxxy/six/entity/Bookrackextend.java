package xxxy.six.entity;

import java.util.Date;
//�������ʵ���� ֻ����ҳ����ʾ �����ݿ��в�û�б�
public class Bookrackextend {
private int paiming;
private int bookid;
private String bookname;
private Date jietime;
private Date huantime;
private String bookauthor;
private String chubanshe;
private int bookflag;
private String bookurl;
private String bookcontent;
private String booklei;


public String getBooklei() {
	return booklei;
}
public void setBooklei(String booklei) {
	this.booklei = booklei;
}
public int getBookid() {
	return bookid;
}
public void setBookid(int bookid) {
	this.bookid = bookid;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public Date getJietime() {
	return jietime;
}
public void setJietime(Date jietime) {
	this.jietime = jietime;
}
public Date getHuantime() {
	return huantime;
}
public void setHuantime(Date huantime) {
	this.huantime = huantime;
}
public String getBookauthor() {
	return bookauthor;
}
public void setBookauthor(String bookauthor) {
	this.bookauthor = bookauthor;
}
public String getChubanshe() {
	return chubanshe;
}
public void setChubanshe(String chubanshe) {
	this.chubanshe = chubanshe;
}
public int getBookflag() {
	return bookflag;
}
public void setBookflag(int bookflag) {
	this.bookflag = bookflag;
}
public String getBookurl() {
	return bookurl;
}
public void setBookurl(String bookurl) {
	this.bookurl = bookurl;
}
public String getBookcontent() {
	return bookcontent;
}
public void setBookcontent(String bookcontent) {
	this.bookcontent = bookcontent;
}

public int getPaiming() {
	return paiming;
}
public void setPaiming(int paiming) {
	this.paiming = paiming;
}

public Bookrackextend(int paiming, int bookid, String bookname, Date jietime,
		Date huantime, String bookauthor, String chubanshe, int bookflag,
		String bookurl, String bookcontent, String booklei) {
	super();
	this.paiming = paiming;
	this.bookid = bookid;
	this.bookname = bookname;
	this.jietime = jietime;
	this.huantime = huantime;
	this.bookauthor = bookauthor;
	this.chubanshe = chubanshe;
	this.bookflag = bookflag;
	this.bookurl = bookurl;
	this.bookcontent = bookcontent;
	this.booklei = booklei;
}
public Bookrackextend(int bookid, String bookname, Date jietime,
		Date huantime, String bookauthor, String chubanshe, int bookflag,
		String bookurl, String bookcontent, String booklei) {
	super();
	this.bookid = bookid;
	this.bookname = bookname;
	this.jietime = jietime;
	this.huantime = huantime;
	this.bookauthor = bookauthor;
	this.chubanshe = chubanshe;
	this.bookflag = bookflag;
	this.bookurl = bookurl;
	this.bookcontent = bookcontent;
	this.booklei = booklei;
}
public Bookrackextend(int bookid, String bookname, Date jietime,
		Date huantime, int bookflag, String bookurl, String booklei) {
	super();
	this.bookid = bookid;
	this.bookname = bookname;
	this.jietime = jietime;
	this.huantime = huantime;
	this.bookflag = bookflag;
	this.bookurl = bookurl;
	this.booklei = booklei;
}
public Bookrackextend() {
	super();
}
@Override
public String toString() {
	return "Bookrackextend [paiming=" + paiming + ", bookid=" + bookid
			+ ", bookname=" + bookname + ", jietime=" + jietime + ", huantime="
			+ huantime + ", bookauthor=" + bookauthor + ", chubanshe="
			+ chubanshe + ", bookflag=" + bookflag + ", bookurl=" + bookurl
			+ ", bookcontent=" + bookcontent + ", booklei=" + booklei + "]";
}



}
