package xxxy.six.entity;

import java.util.Date;

public class Reader {
	private int id;
	private String readbookid;
	private String password;
	private String name;
	private String readersex;
	private String personid;
	private String phone;
	private String email;
	private int flag;
	private Date recorddate;
	private Date validuntil;
	private int booknum;
	
	public String getReadersex() {
		return readersex;
	}

	public void setReadersex(String readersex) {
		this.readersex = readersex;
	}

	public Date getRecorddate() {
		return recorddate;
	}

	public void setRecorddate(Date recorddate) {
		this.recorddate = recorddate;
	}

	public Date getValiduntil() {
		return validuntil;
	}

	public void setValiduntil(Date validuntil) {
		this.validuntil = validuntil;
	}

	public int getBooknum() {
		return booknum;
	}

	public void setBooknum(int booknum) {
		this.booknum = booknum;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}



	public String getReadbookid() {
		return readbookid;
	}

	public void setReadbookid(String readbookid) {
		this.readbookid = readbookid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPersonid() {
		return personid;
	}

	public void setPersonid(String personid) {
		this.personid = personid;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public Reader(int id, String readbookid, String password, String name,
			String readersex, String personid, String phone, String email,
			int flag, Date recorddate, Date validuntil, int booknum) {
		super();
		this.id = id;
		this.readbookid = readbookid;
		this.password = password;
		this.name = name;
		this.readersex = readersex;
		this.personid = personid;
		this.phone = phone;
		this.email = email;
		this.flag = flag;
		this.recorddate = recorddate;
		this.validuntil = validuntil;
		this.booknum = booknum;
	}

	public Reader(String readbookid, String password, String name,
			String readersex, String personid, String phone, String email,
			int flag, Date recorddate, Date validuntil, int booknum) {
		super();
		this.readbookid = readbookid;
		this.password = password;
		this.name = name;
		this.readersex = readersex;
		this.personid = personid;
		this.phone = phone;
		this.email = email;
		this.flag = flag;
		this.recorddate = recorddate;
		this.validuntil = validuntil;
		this.booknum = booknum;
	}

	public Reader() {
		super();
	}

	@Override
	public String toString() {
		return "Reader [id=" + id + ", readbookid=" + readbookid
				+ ", password=" + password + ", name=" + name + ", readersex="
				+ readersex + ", personid=" + personid + ", phone=" + phone
				+ ", email=" + email + ", flag=" + flag + ", recorddate="
				+ recorddate + ", validuntil=" + validuntil + ", booknum="
				+ booknum + "]";
	}

}
