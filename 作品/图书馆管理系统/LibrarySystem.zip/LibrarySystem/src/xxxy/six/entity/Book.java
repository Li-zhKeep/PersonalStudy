package xxxy.six.entity;

import java.util.Date;

public class Book {
	private int bookid;
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getBooklei() {
		return booklei;
	}
	public void setBooklei(String booklei) {
		this.booklei = booklei;
	}
	public int getBooknum() {
		return booknum;
	}
	public void setBooknum(int booknum) {
		this.booknum = booknum;
	}
	public int getBooksheng() {
		return booksheng;
	}
	public void setBooksheng(int booksheng) {
		this.booksheng = booksheng;
	}
	public String getBookauthor() {
		return bookauthor;
	}
	public void setBookauthor(String bookauthor) {
		this.bookauthor = bookauthor;
	}
	public String getBooklocation() {
		return booklocation;
	}
	public void setBooklocation(String booklocation) {
		this.booklocation = booklocation;
	}
	public int getJienum() {
		return jienum;
	}
	public void setJienum(int jienum) {
		this.jienum = jienum;
	}
	public String getBookcontent() {
		return bookcontent;
	}
	public void setBookcontent(String bookcontent) {
		this.bookcontent = bookcontent;
	}
	public Date getBooktime() {
		return booktime;
	}
	public void setBooktime(Date booktime) {
		this.booktime = booktime;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getBookurl() {
		return bookurl;
	}
	public void setBookurl(String bookurl) {
		this.bookurl = bookurl;
	}
	public String getChubanshe() {
		return chubanshe;
	}
	public void setChubanshe(String chubanshe) {
		this.chubanshe = chubanshe;
	}
	public int getPaiming() {
		return paiming;
	}
	public void setPaiming(int paiming) {
		this.paiming = paiming;
	}
	private String bookname;
	private String booklei;
	private int booknum;
	private int booksheng;
	private String bookauthor;
	private String booklocation;
	private int jienum;
	private String bookcontent;
	private Date booktime;
	private String filename; //�ϴ��ļ����ƣ��ļ�����
	private String bookurl;
	private String chubanshe;
	private int paiming;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((bookauthor == null) ? 0 : bookauthor.hashCode());
		result = prime * result
				+ ((bookcontent == null) ? 0 : bookcontent.hashCode());
		result = prime * result + bookid;
		result = prime * result + ((booklei == null) ? 0 : booklei.hashCode());
		result = prime * result
				+ ((booklocation == null) ? 0 : booklocation.hashCode());
		result = prime * result
				+ ((bookname == null) ? 0 : bookname.hashCode());
		result = prime * result + booknum;
		result = prime * result + booksheng;
		result = prime * result
				+ ((booktime == null) ? 0 : booktime.hashCode());
		result = prime * result + ((bookurl == null) ? 0 : bookurl.hashCode());
		result = prime * result
				+ ((chubanshe == null) ? 0 : chubanshe.hashCode());
		result = prime * result
				+ ((filename == null) ? 0 : filename.hashCode());
		result = prime * result + jienum;
		result = prime * result + paiming;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (bookauthor == null) {
			if (other.bookauthor != null)
				return false;
		} else if (!bookauthor.equals(other.bookauthor))
			return false;
		if (bookcontent == null) {
			if (other.bookcontent != null)
				return false;
		} else if (!bookcontent.equals(other.bookcontent))
			return false;
		if (bookid != other.bookid)
			return false;
		if (booklei == null) {
			if (other.booklei != null)
				return false;
		} else if (!booklei.equals(other.booklei))
			return false;
		if (booklocation == null) {
			if (other.booklocation != null)
				return false;
		} else if (!booklocation.equals(other.booklocation))
			return false;
		if (bookname == null) {
			if (other.bookname != null)
				return false;
		} else if (!bookname.equals(other.bookname))
			return false;
		if (booknum != other.booknum)
			return false;
		if (booksheng != other.booksheng)
			return false;
		if (booktime == null) {
			if (other.booktime != null)
				return false;
		} else if (!booktime.equals(other.booktime))
			return false;
		if (bookurl == null) {
			if (other.bookurl != null)
				return false;
		} else if (!bookurl.equals(other.bookurl))
			return false;
		if (chubanshe == null) {
			if (other.chubanshe != null)
				return false;
		} else if (!chubanshe.equals(other.chubanshe))
			return false;
		if (filename == null) {
			if (other.filename != null)
				return false;
		} else if (!filename.equals(other.filename))
			return false;
		if (jienum != other.jienum)
			return false;
		if (paiming != other.paiming)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", bookname=" + bookname
				+ ", booklei=" + booklei + ", booknum=" + booknum
				+ ", booksheng=" + booksheng + ", bookauthor=" + bookauthor
				+ ", booklocation=" + booklocation + ", jienum=" + jienum
				+ ", bookcontent=" + bookcontent + ", booktime=" + booktime
				+ ", filename=" + filename + ", bookurl=" + bookurl
				+ ", chubanshe=" + chubanshe + ", paiming=" + paiming + "]";
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}





	
}
