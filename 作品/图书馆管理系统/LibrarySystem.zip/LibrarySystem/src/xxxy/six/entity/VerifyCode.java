package xxxy.six.entity;

import java.util.Date;

public class VerifyCode {
	private String verifycode;
	private String username;
	private String email;
	private Date createtime;
	private Integer status;
	public String getVerifycode() {
		return verifycode;
	}
	public void setVerifycode(String verifycode) {
		this.verifycode = verifycode;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((createtime == null) ? 0 : createtime.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result
				+ ((username == null) ? 0 : username.hashCode());
		result = prime * result
				+ ((verifycode == null) ? 0 : verifycode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VerifyCode other = (VerifyCode) obj;
		if (createtime == null) {
			if (other.createtime != null)
				return false;
		} else if (!createtime.equals(other.createtime))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		if (verifycode == null) {
			if (other.verifycode != null)
				return false;
		} else if (!verifycode.equals(other.verifycode))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "VerifyCode [verifycode=" + verifycode + ", username="
				+ username + ", email=" + email + ", createtime=" + createtime
				+ ", status=" + status + "]";
	}
	public VerifyCode(String verifycode, String username, String email,
			Date createtime, Integer status) {
		super();
		this.verifycode = verifycode;
		this.username = username;
		this.email = email;
		this.createtime = createtime;
		this.status = status;
	}
	public VerifyCode() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
