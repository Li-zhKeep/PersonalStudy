package xxxy.six.entity;

import java.util.Date;

public class JSON_reader {
	private String readbookid;
	private String name;
	private String readersex;
	private String personid;
	private String email;
	private String phone;
	public String getReadbookid() {
		return readbookid;
	}
	public void setReadbookid(String readbookid) {
		this.readbookid = readbookid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPersonid() {
		return personid;
	}
	public void setPersonid(String personid) {
		this.personid = personid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getReadersex() {
		return readersex;
	}
	public void setReadersex(String readersex) {
		this.readersex = readersex;
	}
	@Override
	public String toString() {
		return "JSON_reader [readbookid=" + readbookid + ", name=" + name + ", personid=" + personid
				+ ", email=" + email + ", phone=" + phone + ", readersex="
				+ readersex + "]";
	}
	public JSON_reader(String readbookid, String name,
			String personid, String email, String phone, String readersex) {
		super();
		this.readbookid = readbookid;
		this.name = name;
		this.personid = personid;
		this.email = email;
		this.phone = phone;
		this.readersex = readersex;
	}
	
}
