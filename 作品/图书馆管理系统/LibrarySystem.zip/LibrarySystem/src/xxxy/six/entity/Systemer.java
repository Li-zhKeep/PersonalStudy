package xxxy.six.entity;

public class Systemer {
	private int id;
	private String systemid;
	private String password;
	private String systemname;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSystemid() {
		return systemid;
	}
	public void setSystemid(String systemid) {
		this.systemid = systemid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSystemname() {
		return systemname;
	}
	public void setSystemname(String systemname) {
		this.systemname = systemname;
	}
	public Systemer(int id, String systemid, String password, String systemname) {
		super();
		this.id = id;
		this.systemid = systemid;
		this.password = password;
		this.systemname = systemname;
	}
	public Systemer(String systemid, String password, String systemname) {
		super();
		this.systemid = systemid;
		this.password = password;
		this.systemname = systemname;
	}
	public Systemer() {
		super();
	}
	@Override
	public String toString() {
		return "Systemer [id=" + id + ", systemid=" + systemid + ", password="
				+ password + ", systemname=" + systemname + "]";
	}

}
