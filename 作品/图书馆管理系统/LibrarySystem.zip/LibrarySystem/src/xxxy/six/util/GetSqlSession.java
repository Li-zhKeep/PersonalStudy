package xxxy.six.util;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class GetSqlSession {
	static SqlSessionFactory factory;
	static SqlSession sqlsession;
	static{
		SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
		Reader rs = null;
		try {
			rs = Resources.getResourceAsReader("mybatis-config.xml");
		} catch (IOException e) {
			e.printStackTrace();
		}
		factory = builder.build(rs);
		sqlsession = factory.openSession();
	}
public static SqlSession get(){
		return sqlsession;

}
public static void commit(){
	get().commit();
}
public static void close(){
	get().close();
}
}
